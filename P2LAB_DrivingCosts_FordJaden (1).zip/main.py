# taking mileage input
mileage = eval(input())

# taking cost_of_gas input
cost_of_gas = eval(input())

#calculating value1
your_value1 = 20 * (cost_of_gas / mileage)

#calculating value2
your_value2 = 75 * (cost_of_gas / mileage)

#calculating value3
your_value3 = 500 * (cost_of_gas / mileage)
# printing values with 2 decimal places
print(f'{your_value1:.2f} {your_value2:.2f} {your_value3:.2f}')