num1 = float(input())
num2 = float(input())
num3 = float(input())
num4 = float(input())

product_all  =  num1*num2*num3*num4
sum_all = (num1+num2+num3+num4)/4
print(f"{product_all:.0f} {sum_all:.0f}")
print(f"{product_all:.3f} {sum_all:.3f}")
